struct Point2D
{
	int x = 0;
	int y = 0;
};